const API_URL = 'exp://192.168.1.3:8081'; 

export { API_URL };